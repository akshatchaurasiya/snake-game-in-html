<?php

    require_once(__DIR__ . '/../../config.php');
    require_once($CFG->dirroot . '/local/user/classes/form/edit.php');

    global $DB;

    $PAGE->set_url(new moodle_url('/local/user/edit.php'));
    $PAGE->set_context(\context_system::instance());
    $PAGE->set_title('edit');


    // dispaly form
    $mform = new edit();

    if ($mform->is_cancelled()) {
      redirect('index.php', 'You canceled the class form');
    }
    else if ($fromform = $mform->get_data()) {

      // $DB->insert_record('user', $recordinsert);
      // redirect($CFG->wwwroot . '/local/user/index.php', 'Your class successfully created');

    }

    echo $OUTPUT->header();

     $mform->display();

    echo $OUTPUT->footer();
