// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Add a create new group modal to the page.
 *
 * @module     local_user/form
 * @class      form
 * @package    local_user
 * @copyright  eabhyas
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'core/str', 'core/modal_factory', 'core/modal_events', 'core/fragment', 'core/ajax', 'core/yui', 'core/templates', 'core/notification'],
        function($, Str, ModalFactory, ModalEvents, Fragment, Ajax, Y, Templates, Notification) {
          var formAjax = function(args) {
                this.contextid = args.contextid || 1;
                this.args = args;
                var self=this;
                self.init(args);
          };


        /**
         * @var {Modal} modal
         * @private
         */
        formAjax.prototype.modal = null;

        /**
         * @var {int} contextid
         * @private
         */
        formAjax.prototype.contextid = -1;

           /**
     * Initialise the class.
     *
     * @param {String} selector used to find triggers for the new group modal.
     * @private
     * @return {Promise}
     */
    formAjax.prototype.init = function(args) {

      var self = this;

       var self = this;
       if (args.id) {
            var head =  Str.get_string('edituser', 'local_user',args);
        } else {

           var head = Str.get_string('adduser', 'local_user');
        }
        return head.then(function(title) {
            // Create the modal.
            return ModalFactory.create({
                type: ModalFactory.types.DEFAULT,
                title: title,
                body: this.getBody(),
                footer: this.getFooter(),
            });
        }.bind(this)).then(function(modal) {
            // Keep a reference to the modal.
            this.modal = modal;

            // Forms are big, we want a big modal.
            this.modal.setLarge();

            // We want to reset the form every time it is opened.
            this.modal.getRoot().on(ModalEvents.hidden, function() {
                 setTimeout(function(){
                    modal.destroy();
                }, 1000);
                this.modal.setBody('');
            }.bind(this));

            // We want to hide the submit buttons every time it is opened.

            this.modal.getFooter().find('[data-action="save"]').on('click', this.submitForm.bind(this));

            this.modal.getFooter().find(['data-action = cancel']).on('click', function(){

              modal.setBody('');

              modal.hide();

              setTimeout(function () {
                  modal.destroy();
              },1000)

             });

            this.modal.getFooter().find('[data-action="cancel"]').on('click', function() {
                modal.hide();
                setTimeout(function(){
                    modal.destroy();
                }, 1000);
                 //modal.destroy();
            });
            this.modal.getRoot().on('submit', 'form', function(form) {
                self.submitformAjax(form, self.args);
            });
            this.modal.show();
            return this.modal;
        }.bind(this));

    };

    formAjax.prototype.getBody = function(formdata) {
        if (typeof formdata === "undefined") {
            formdata = {};
        }
        // Get the content of the modal.
        this.args.jsonformdata = JSON.stringify(formdata);
        return Fragment.loadFragment(this.args.component, this.args.callback, this.contextid, this.args);
       // return Fragment.loadFragment('local_user', 'custom_class_form', this.contextid, this.args);
    };

    formAjax.prototype.getFooter=function () {

        //var classname=this.args.classname;

        if (this.args.id) {

           // $footer='<button type="button" class="btn btn-primary" data-action="save">Update ' + this.args.classname + ' Class</button>'

           $footer='<button type="button" class="btn btn-primary" data-action="save">Update User</button>'

        }else{

            $footer='<button type="button" class="btn btn-primary" data-action="save">Create User</button>'

        }

        $footer += '<button type="button" class="btn btn-secondary" data-action="cancel">Cancel</button>'

                 return $footer;
    };


   formAjax.prototype.getcontentFooter=function(){

      $footer = '<button type="button" class="btn btn-secondary" data-action="cancel">Cancel</button>'

      return $footer;

   };

    formAjax.prototype.handleFormSubmissionResponse = function() {

    // We could trigger an event instead.
    // Yuk.
    Y.use('moodle-core-formchangechecker', function() {
        M.core_formchangechecker.reset_form_dirty_state();
    });
          this.modal.hide();
          window.location.reload();
          window.location.href = window.location.href;

    };

   //  /**
   //   * @method handleFormSubmissionFailure
   //   * @private
   //   * @return {Promise}
   //   */
    formAjax.prototype.handleFormSubmissionFailure = function(data) {
        // Oh noes! Epic fail :(
        // Ah wait - this is normal. We need to re-display the form with errors!
        this.modal.setBody(this.getBody(data));
    };

     formAjax.prototype.submitformAjax = function(e, args) {
        // We don't want to do a real form submission.
        e.preventDefault();
        var self = this;
        // Convert all the form elements values to a serialised string.
        var formData = this.modal.getRoot().find('form').serialize();
       // var methodname = args.plugintype + '_' + args.pluginname + '_submit_create_class_form';
        var params = {};
        params.contextid = this.contextid;
        params.id = args.id
        params.jsonformdata = JSON.stringify(formData);

        var promise = Ajax.call([{
            methodname: 'local_user_submit_register',
            args: params
        }]);
        promise[0].done(function(resp){
                self.args.id = resp.id;
                self.args.contextid = resp.contextid;
                self.handleFormSubmissionResponse(self.args);
                //self.successmessage();
                window.location.reload();
                window.location.href = window.location.href;


        }).fail(function(){
            self.handleFormSubmissionFailure(formData);
        });

    };

    formAjax.prototype.submitForm = function(e) {
        e.preventDefault();
        this.modal.getRoot().find('form').submit();
    };

     return  {
        init: function(args) {
           return new formAjax(args);
        },

        deleteConfirm: function(args){
            return Str.get_strings([{
                key: 'confirm',
                component: 'local_user',
            },
            {
                key: 'deleteconfirm',
                component: 'local_user',
                param : args
            },
            {
                key: 'delete'
            }]).then(function(s) {
                ModalFactory.create({
                    title: s[0],
                    type: ModalFactory.types.DEFAULT,
                    body: s[1],
                    footer: '<button type="button" class="btn btn-primary" data-action="save">Yes</button>&nbsp;' +
            '<button type="button" class="btn btn-secondary" data-action="cancel">No</button>'
                }).done(function(modal) {
                    this.modal = modal;

                    modal.getRoot().find('[data-action="save"]').on('click', function() {
                        args.confirm = true;
                        var promise = Ajax.call([{
                            methodname: 'local_user_' + args.action,
                            args: {
                                id: args.id,
                            },
                        }]);
                        promise[0].done(function() {
                            window.location.reload();
                            window.location.href = window.location.href;
                       }).fail(function(ex) {
                            // do something with the exception
                             console.log(ex);
                        });
                    }.bind(this));
                    modal.getFooter().find('[data-action="cancel"]').on('click', function() {
                        modal.setBody('');
                        modal.hide();
                    });
                    modal.show();
                }.bind(this));
            }.bind(this));
        },


       load:function () {}

    };

});
