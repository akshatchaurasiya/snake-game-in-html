<?php

    require_once(__DIR__. '/../../config.php');
    require_once($CFG->libdir.'/formslib.php');
    require_once($CFG->dirroot . '/local/user/classes/form/edit.php');

    global $DB, $PAGE;

    $context = context_system::instance();

    $PAGE->requires->jquery();
    $PAGE->set_url(new moodle_url('/local/user/index.php'));
    $PAGE->requires->js_call_amd('local_user/formAjax','load',array());
    $PAGE->set_context(\context_system::instance());
    $PAGE->set_heading(get_string('records','local_user'));
    $PAGE->set_title('user');

    $result = $DB->get_records('user');

    echo $OUTPUT->header();

    $templatecontext = [
    'result' => array_values($result),

    ];
    echo $OUTPUT->render_from_template('local_user/index', $templatecontext);
    echo $OUTPUT->footer();
