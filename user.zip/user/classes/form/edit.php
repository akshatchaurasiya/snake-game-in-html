<?php

/**
 * Category enrolment plugin version specification.
 *
 * @package    local_user
 * @copyright  aman
 * @license    eabyas
 */

    namespace local_user\form;
    require_once("$CFG->libdir/formslib.php");
    use core;
    use moodleform;
    use context_system;
  class edit extends moodleform {
    public function definition() {

        global $CFG;

        $mform = $this->_form; // Don't forget the underscore!
        $id = $this->_customdata['id'];

        $strgeneral  = get_string('general');

        $mform->addElement('hidden', 'id'); // Add elements to your form.
        $mform->setType('id', PARAM_INT);                   // Set type of element.

        $mform->addElement('header', 'moodle', $strgeneral);

        $mform->addElement('text', 'username', 'Username'); // Add elements to your form.
        $mform->setType('username', PARAM_TEXT);                   // Set type of element.

        $mform->addElement('passwordunmask', 'password', 'New Password');
        $mform->setType('password', PARAM_TEXT);

        $mform->addElement('text', 'firstname', 'First Name'); // Add elements to your form.
        $mform->setType('firstname', PARAM_TEXT);                   // Set type of element.
        $mform->addRule('firstname', null, 'required');
        $mform->addRule('firstname', null, 'lettersonly');

        $mform->addElement('text', 'lastname', 'Surname'); // Add elements to your form.
        $mform->setType('lastname', PARAM_TEXT);                   // Set type of element.
        $mform->addRule('lastname', null, 'required');
        $mform->addRule('lastname', null, 'lettersonly');

        $mform->addElement('text', 'email', get_string('email'), 'pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"'); // Add elements to your form.
        $mform->setType('email', PARAM_TEXT);
        $mform->addRule('email', null, 'required');                // Set type of element.

        $mform->addElement('text', 'city', 'City/town');
        $mform->setType('city', PARAM_TEXT);

        $choices = get_string_manager()->get_list_of_countries();
        $choices = array('' => get_string('selectacountry') . '...') + $choices;
        $mform->addElement('select', 'country', get_string('selectacountry'), $choices);

        $mform->addElement('editor', 'description',get_string('description'), 'Description'); // Add elements to your form.
        $mform->setType('description', PARAM_TEXT);
        $mform->addHelpButton('description', 'description');


      }
}
