<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/externallib.php');
require_once($CFG->libdir.'/filelib.php');
require_once($CFG->dirroot.'/user/lib.php');

/**
 * Files external functions
 *
 * @package    local_user
 * @category   external
 * @copyright  2022 aman
 * @license    eabyas
 * @since Moodle 2.2
 */
 use local_user\form\edit as edit;

class local_user_external extends external_api {

    /**
     * Returns description of get_files parameters
     *
     * @return external_function_parameters
     * @since Moodle 2.2
     */
     public static function submit_register_parameters() {

          return new external_function_parameters(
            array(
                'contextid' => new external_value(PARAM_INT, 'The context id for the system',0),
                'id' => new external_value(PARAM_INT,'Class id',0),
                'jsonformdata' => new external_value(PARAM_RAW, 'The data from the create class form, encoded as a json array')
            )
        );
    }
    public static function submit_register($contextid, $id, $jsonformdata) {

        global $CFG,$DB,$USER;

         //require_once($CFG->dirroot . '/local/user/lib.php');

        $params=self::validate_parameters(

            self::submit_register_parameters(),
            array('contextid'=>$contextid,'id'=>$id,'jsonformdata'=>$jsonformdata)
        );
        $context=context::instance_by_id($params['contextid'],'MUST_EXIST');

        self::validate_context($context);

         $serialiseddata=json_decode($params['jsonformdata']);

         $data=array();

         parse_str($serialiseddata, $data);

        $warnings = array();


         $mform = new edit(null, array('id'=>$id), 'post', '', null, true, $data);

        $validateddata = $mform->get_data();

          // var_dump($validateddata);
          // exit;
          if ($validateddata) {

            // if($validateddata->id == -1) {
            if($validateddata->id > 0) {



                $updaterec = new \stdClass();
                $updaterec->id          = user_create_user($updaterec, false, false);
                $updaterec->username    = $validateddata->username;
                $updaterec->password    = hash_internal_user_password($validateddata->password);
                $updaterec->firstname   = $validateddata->firstname;
                $updaterec->lastname    = $validateddata->lastname;
                $updaterec->email       = $validateddata->email;
                $updaterec->city        = $validateddata->city;
                $updaterec->country     = $validateddata->country;
                $updaterec->description = $validateddata->description['text'];
                // print_r($updaterec);die;
                $usernew->id = user_update_user($usernew, false, false);
                // $updateuserser->id = user_create_user($updaterec);

                // $courseupdaterecord = $DB->update_record('user', $updaterec);

            } else  {
               $usernew = new \stdClass();
               // $usernew->id          = user_create_user($validateddata, false, false);
               $usernew->username    = $validateddata->username;
               $usernew->password    = hash_internal_user_password($usernew->username);
               $usernew->firstname   = $validateddata->firstname;
               $usernew->lastname    = $validateddata->lastname;
               $usernew->email       = $validateddata->email;
               $usernew->city        = $validateddata->city;
               $usernew->country     = $validateddata->country;
               $usernew->description = $validateddata->description['text'];
               // print_r($usernew);die;

               user_create_user($usernew, false, false);

               // $usernew->id = user_create_user($usernew, false, false);

               // $insertrecord = $DB->insert_record('user', $insert);


            }
            } else {
            // Generate a warning.
           throw new moodle_exception('Error in submission');
        }
        $return = array(
            'id' => $id,
            'contextid' => $contextid,
        );

        return $return;
        }

    public static function submit_register_returns() {

         return new external_single_structure(array(
            'id' => new external_value(PARAM_INT, ' id'),
            'contextid' => new external_value(PARAM_INT, 'The context id for the system',0),

        ));
    }
    public static function deleteclass_parameters() {
        return new external_function_parameters(
            array(
                'id'  => new external_value(PARAM_INT, 'id',0),
                // 'classname'  => new external_value(PARAM_INT, 'classname',0),
            )
        );
    }
    public static function deleteclass($id) {
        global $DB;

        $params = self::validate_parameters (

               self::deleteclass_parameters(),array('id'=>$id)
               // self::deleteclass_parameters(),array('classname'=>$classname)
       );
        $context = context_system::instance();
        self::validate_context($context);
        if($id) {
            $delete = $DB->delete_records('user',array('id'=>$id));
        } else {
            throw new moodle_exception('Error');
        }
     }
     public static function deleteclass_returns(){

        return null;
     }
}
