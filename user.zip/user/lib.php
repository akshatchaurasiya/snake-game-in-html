<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details
 *
 * @package    local_user
 * @copyright  aman
 * @license    eabhays
 */

 function local_user_extend_navigation(global_navigation $navigation)
 {
   if(!has_capability('moodle/site:config', context_system::instance())){
     return;
   }
   $main_node = $navigation->add(get_string('pluginname', 'local_user'), '/local/user/index.php');
   $main_node->nodetype = 1;
   $main_node->collapse = false;
   $main_node->forceopen = true;
   $main_node->isexpandable = false;
   $main_node->showinflatnavigation = true;
 }


defined('MOODLE_INTERNAL') || die();

use local_user\form\edit as edit;

function local_user_output_fragment_edit($args) {
    global $CFG,$PAGE,$DB,$USER;

    $args = (object) $args;
    $id = $args->id;

    $val = '';
   if ($id) {
        $record = $DB->get_record('user', array('id' => $id));
        $syscontext=context_system::instance();

    }
    $formdata = [];
    if (!empty($args->jsonformdata)) {
        $serialiseddata = json_decode($args->jsonformdata);
        parse_str($serialiseddata, $formdata);
    }

    if(!empty($record) && empty($formdata)){
        $formdata = (array)$record;

    }
    // $data = array();

    $data = [];
    if($id) {
      $data=$DB->get_record('user', array('id' => $id));
      $description=$data->description;
      $data->description=array();
      $data->description['text']=$description;

    }
    $mform = new edit(null, (array)$data, 'post', '', null, true, $formdata);
    $mform->set_data($data);
     if (!empty($args->jsonformdata) && strlen($args->jsonformdata)>2) {
        // If we were passed non-empty form data we want the mform to call validation functions and show errors.
        $mform->is_validated();
    }

    ob_start();
    $mform->display();
    $val .= ob_get_contents();
    ob_end_clean();

    return $val;
}
