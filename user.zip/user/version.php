<?php


/**
 * Version details
 *
 * @package    local_user
 * @copyright  aman
 * @license    eabyas
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2022052612;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2020060900;        // Requires this Moodle version
$plugin->component = 'local_user';      // Full name of the plugin (used for diagnostics)
