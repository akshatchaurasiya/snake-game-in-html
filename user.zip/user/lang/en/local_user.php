<?php
    $string['pluginname']='Local user';
    $string['records']='Records';
    $string['adduser']='Adduser';
    $string['confirm']='Confirm';
    $string['deleteconfirm']='Deleteconfirm';
    $string['edituser']='EditUser';
